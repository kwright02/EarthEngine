package me.kw.ee;

public enum BorderDirection {
 UP,DOWN,LEFT,RIGHT
}
